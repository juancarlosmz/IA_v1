app.factory('products', ['$http', function($http) { 
    return function(response){}          
  }]);